#!/bin/bash
cd /home/test/桌面/testdoc/

echo "===== aarch64 qemu-user test ====="
qemu-aarch64 -L /usr/aarch64-linux-gnu /tmp/antiword-v12-aarch64 -t -m UTF-8.txt "这是doc文档 - plain.doc" 2>&1 | head -3
echo "aarch64 plain RC: $?"

echo ""
echo "===== loongarch64 qemu-user test ====="
qemu-loongarch64 -L /opt/loongson-gnu-toolchain-8.3-x86_64-loongarch64-linux-gnu-rc1.5/loongarch64-linux-gnu/sysroot /tmp/antiword-v12-loongarch64 -t -m UTF-8.txt "这是doc文档 - plain.doc" 2>&1 | head -3
echo "loongarch64 plain RC: $?"

echo ""
echo "===== aarch64 plaindocx.docx (should say ZIP) ====="
qemu-aarch64 -L /usr/aarch64-linux-gnu /tmp/antiword-v12-aarch64 -t -m UTF-8.txt "plaindocx.docx" 2>&1 | head -3
echo "aarch64 docx RC: $?"

echo ""
echo "===== loongarch64 plaindocx.docx (should say ZIP) ====="
qemu-loongarch64 -L /opt/loongson-gnu-toolchain-8.3-x86_64-loongarch64-linux-gnu-rc1.5/loongarch64-linux-gnu/sysroot /tmp/antiword-v12-loongarch64 -t -m UTF-8.txt "plaindocx.docx" 2>&1 | head -3
echo "loongarch64 docx RC: $?"

echo ""
echo "===== aarch64 CUPT介绍.doc ====="
qemu-aarch64 -L /usr/aarch64-linux-gnu /tmp/antiword-v12-aarch64 -t -m UTF-8.txt "CUPT介绍.doc" 2>&1 | head -3
echo "aarch64 cupt RC: $?"

echo ""
echo "===== loongarch64 CUPT介绍.doc ====="
qemu-loongarch64 -L /opt/loongson-gnu-toolchain-8.3-x86_64-loongarch64-linux-gnu-rc1.5/loongarch64-linux-gnu/sysroot /tmp/antiword-v12-loongarch64 -t -m UTF-8.txt "CUPT介绍.doc" 2>&1 | head -3
echo "loongarch64 cupt RC: $?"
