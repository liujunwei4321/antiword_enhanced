#!/bin/bash
cd /home/test/桌面/testdoc/

# Run with v12 build
for f in "这是doc文档 - plain.doc" "CUPT介绍.doc" "这是doc文档.doc"; do
    if [ -f "$f" ]; then
        echo "===== $f ====="
        env ANTIWORDHOME=/usr/share/antiword LANG=zh_CN.UTF-8 /tmp/antiword-v12-build/antiword -t -m UTF-8.txt "$f" > /tmp/v12_out_"$f".txt 2>&1
        echo "RC: $?"
        md5sum /tmp/v12_out_"$f".txt
    fi
done

# Compare with baseline
echo ""
echo "===== Byte comparison with baseline ====="
for f in "这是doc文档 - plain.doc" "CUPT介绍.doc" "这是doc文档.doc"; do
    if [ -f /tmp/antiword-test-results/"$f".txt ]; then
        baseline_md5=$(md5sum /tmp/antiword-test-results/"$f".txt | awk '{print $1}')
        v12_md5=$(md5sum /tmp/v12_out_"$f".txt | awk '{print $1}')
        echo "$f: baseline=$baseline_md5 v12=$v12_md5 $([ "$baseline_md5" = "$v12_md5" ] && echo MATCH || echo DIFFER)"
    fi
done
