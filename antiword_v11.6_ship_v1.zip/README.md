# antiword v11.6 (P1 NULL fix) ship bundle

**Generated**: 2026-06-30 19:11
**Size**: ~2.5 MB total
**Format**: This is a flat-folder bundle (not zipped — use 7z/zip if you need a single archive)

## What's in this folder

| Subdir | Contents | Files |
|---|---|---|
| `binaries/` | 6 ship binaries (Linux 3 + Windows 3) | 6 |
| `source/` | Modified source files (v11.5 baseline + Round 2 wordole.c + v11.6 wordlib.c 3 NULL guards) | 16 |
| `pristine/` | Antiword 0.37 vendor baseline (full source) | 71 |
| `diff/` | Round 1 vendor diffs (12 files, vendor → our, small-block fix 5 阶段) | 12 |
| `scripts/` | Build + test + audit scripts | 13 |
| `reports/` | Ship report + DeepSeek audit report + reasoning | 4 |
| `test_docs/` | 4 .doc test files + 1 .docx for verification | 5 |
| `SHA256SUMS.txt` | SHA256 of all 6 binaries | — |

## What changed in v11.6

| File | v11.5 → v11.6 |
|---|---|
| `source/wordlib.c` | +3 NULL guards (bIsZipFile / bIsXMLFile / bIsHTMLFile) — DeepSeek P1 fix |
| `source/wordole.c` | Round 2: `< 4` → `< 0x20` (32) min header size + zero-pad for downstream parser safety |
| `source/wordlib.c` | (other v11.5 changes) 6 const UCHAR + bIsZipFile / bIsXMLFile / bIsHTMLFile from Recoll fork docx.patch |
| `source/main_u.c` | (v11.5 changes) 4 else-if error paths + execdir_setargv0 from Recoll fork |
| `source/misc.c` | (v11.5 changes) bReadStream() helper for big/small block dispatch |
| `source/antiword.h` | (v11.5 changes) bReadStream decl + 3 bIs*File decls |
| `source/execdir.c` | (v11.5 changes) Recoll ported + _POSIX_C_SOURCE 200809L fix |
| `source/execdir.h` | (v11.5 changes) Recoll header |
| 9 other source files | (v11.5 Round 1) 5-stage small-block OLE2 fix (finddata.c, findtext.c, notes.c, prop6.c, prop8.c, properties.c, stylesheet.c, tabstop.c, fonts.c) |

## Why this fix exists

DeepSeek 2 rounds of audit (system prompt + user prompt carefully tuned for independence + real code path verification) caught **1 P1 high bug** in v11.5:

```c
// wordlib.c — bIsZipFile / bIsXMLFile / bIsHTMLFile
// fail() in NDEBUG is noop; bCheckBytes validates via fail() so pFile=NULL crashes downstream
if (pFile == NULL) {  // P1 fix added
    return FALSE;
}
```

The full audit report: `reports/antiword_v11_5_audit.md` (DeepSeek output) + `reports/antiword_v11_5_reasoning.md` (DeepSeek reasoning).

## Build / test workflow

```bash
# Linux x86_64 (gcc 9 on Kylin V10 SP1)
bash scripts/ssh_build.sh

# Cross build aarch64 + loongarch64
bash scripts/ssh_build_cross.sh

# MSVC 3 variants (XP x86 / Win7 x86 / Win7 x64)
cmd /c scripts\build_3variants_v11_6.bat

# Run on testdoc/ (4 .doc files)
bash scripts/testdoc_test.sh
```

## Verification

- 5 sample .doc byte-exact match v11.5 baseline (md5 互相对齐)
- 4 sample .doc byte-exact 3 MSVC 变体对齐
- 0 crash, 0 regression
- Total size 1.4 MB → 1.25 MB (-10.7%)

## Files manifest

```
binaries/antiword_x86_64_v11.6_smallblock_plus_recoll_NULLfix_v1.exe       240440 B
binaries/antiword_aarch64_v11.6_smallblock_plus_recoll_NULLfix_v1          227520 B
binaries/antiword_loongarch64_v11.6_smallblock_plus_recoll_NULLfix_v1     248456 B
binaries/antiword_xp_x86_v11.6_smallblock_plus_recoll_NULLfix_v1.exe       375808 B
binaries/antiword_win7_x86_v11.6_smallblock_plus_recoll_NULLfix_v1.exe     185344 B
binaries/antiword_win7_x64_v11.6_smallblock_plus_recoll_NULLfix_v1.exe     224768 B
```

Total binary size: **1.25 MB** (6 files)

## SHA256 fingerprints (also in `SHA256SUMS.txt`)

```
8EE338782682FDC1D53C87C73EC5B45A6641A72A9F9BEA252F9BCBB766B72A55  antiword_aarch64_v11.6_smallblock_plus_recoll_NULLfix_v1
C23F0885DDB52B22C37181E96BBD1EE8AA58B6E7C3416E9D30BCCC631BD7D0C9  antiword_loongarch64_v11.6_smallblock_plus_recoll_NULLfix_v1
65EF3A9C5C85141F7F892E733EAFCDAA2E338B5EFEEDA97CE23DE4B0BDB00CE5  antiword_win7_x64_v11.6_smallblock_plus_recoll_NULLfix_v1.exe
DC8C7C25CA687B8BDF5A4B70AD5BFF2556F5BB01201302F6EE539125867C87EB  antiword_win7_x86_v11.6_smallblock_plus_recoll_NULLfix_v1.exe
80F83BE7FBA2CC33B744EF9F2E3938649BB03506093CB4BD1A1C00AF03F98E7E  antiword_x86_64_v11.6_smallblock_plus_recoll_NULLfix_v1.exe
55797C24FE5E629043AD4B28D4DE4175D4152C2DAA13D0F4046273E9CB92B1B4  antiword_xp_x86_v11.6_smallblock_plus_recoll_NULLfix_v1.exe
```

## How to verify SHA256

```bash
sha256sum binaries/*       # Linux
certutil -hashfile <file> SHA256   # Windows
```

## Reproducing the build from source

```bash
# 1. Get antiword 0.37 pristine (already in pristine/)
# 2. Apply Round 1 small-block fix patches (see diff/) to get v11.4
# 3. Apply Recoll fork docx.patch + execdir.c to get v11.5
# 4. Apply v11.6 P1 NULL guard to wordlib.c
# 5. Run scripts/ssh_build.sh to build
```

Or with the build script (requires Kylin V10 SP1 + gcc 9 + binutils + cross compilers for aarch64/loongarch64 + MSVC 14.44 for Windows).

## License

Antiword original code: GPL v2
Recoll fork code (docx.patch, execdir.c): MIT (per-file headers preserved)
Recoll extras (bIs*File, main_u.c else-if): MIT (per Recoll LICENSE)

Compiled binaries are GPL-2.0-or-later (antiword project license).
