#!/bin/bash
# Run antiword on all 4 .doc files in testdoc/
cd /home/test/桌面/testdoc/

echo "===== antiword v11.6 v12 testdoc/ folder test ====="
echo ""

# Find all .doc
echo "Files to test:"
find . -maxdepth 1 -type f -name "*.doc" 2>/dev/null
echo ""

# Run each
i=0
TOTAL=$(find . -maxdepth 1 -type f -name "*.doc" 2>/dev/null | wc -l)
SUCC=0
FAIL=0
for f in $(find . -maxdepth 1 -type f -name "*.doc" 2>/dev/null); do
    i=$((i+1))
    name=$(basename "$f")
    out=$(env ANTIWORDHOME=/usr/share/antiword LANG=zh_CN.UTF-8 /tmp/antiword-v12-build/antiword -t -m UTF-8.txt "$f" 2>&1)
    rc=$?
    if [ $rc -eq 0 ]; then
        SUCC=$((SUCC+1))
        preview=$(echo "$out" | head -1)
        echo "  [$i/$TOTAL] PASS rc=$rc  $name"
        echo "          preview: $preview"
    else
        FAIL=$((FAIL+1))
        echo "  [$i/$TOTAL] FAIL rc=$rc  $name"
        echo "          msg: $out"
    fi
done

echo ""
echo "===== SUMMARY ====="
echo "Total:    $i"
echo "Success:  $SUCC"
echo "Failed:   $FAIL"
echo "Max idx:  $i"
