#!/bin/bash
cd /home/test/桌面/testdoc/
for f in 3.doc CUPT介绍.doc 热敏电阻综合实验仪.doc "这是doc文档 - plain.doc"; do
    if [ -f "$f" ]; then
        echo "===== $f ====="
        env ANTIWORDHOME=/usr/share/antiword LANG=zh_CN.UTF-8 /tmp/antiword-v12-build/antiword -t -m UTF-8.txt "$f" 2>&1 | head -10
        echo "RC: ${PIPESTATUS[0]}"
    else
        echo "===== $f [NOT FOUND] ====="
    fi
done

# Test plaindocx.docx
echo "===== plaindocx.docx (should say ZIP file) ====="
env ANTIWORDHOME=/usr/share/antiword LANG=zh_CN.UTF-8 /tmp/antiword-v12-build/antiword -t -m UTF-8.txt plaindocx.docx 2>&1 | head -10
echo "RC: ${PIPESTATUS[0]}"
