/* Copyright (C) 2026 J.F.Dockes
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
#ifndef _EXECDIR_H_INCLUDED_
#define _EXECDIR_H_INCLUDED_

#include <stdlib.h>

/* Try to return the directory where this executable resides.
 *
 * On Linux this supposes that main() has called execdir_setargv0() (we have no direct access to
 * argv). Windows or Mac don't need argv
 *
 * The return value is either the actual directory, which should be freed, or NULL for errors.
 */
extern char *execdir_thisexecdir();

/// Linux/BSD: call this from main to set the value of argv[0]
extern void execdir_setargv0(const char *av0);

#endif /* _EXECDIR_H_INCLUDED_ */
