#!/bin/bash
# Cross-build for aarch64 and loongarch64
set -e

BUILD_DIR=/tmp/antiword-v12-build
cd $BUILD_DIR

OBJS="
main_u.o asc85enc.o blocklist.o chartrans.o datalist.o depot.o
dib2eps.o doclist.o fail.o finddata.o findtext.o fmt_text.o fontlist.o
fonts.o fonts_u.o hdrftrlist.o imgexam.o imgtrans.o jpeg2eps.o
listlist.o misc.o notes.o options.o out2window.o output.o pdf.o
pictlist.o png2eps.o postscript.o prop0.o prop2.o prop6.o prop8.o
properties.o propmod.o rowlist.o sectlist.o stylelist.o stylesheet.o
summary.o tabstop.o text.o unix.o utf8.o word2text.o worddos.o
wordlib.o wordmac.o wordole.o wordwin.o xmalloc.o xml.o execdir.o
"

# Use environment var so CFLAGS doesn't get mangled by quoting
export CFLAGS='-D_POSIX_C_SOURCE=200809L -DNDEBUG -DUNIX -DGLOBAL_ANTIWORD_DIR="/usr/share/antiword/" -I. -O2'

# aarch64 build
echo "===== aarch64 build ====="
rm -f /tmp/antiword_v12_*.o
for f in $OBJS; do
    base=${f%.o}
    aarch64-linux-gnu-gcc $CFLAGS -c -o /tmp/antiword_v12_$f ${base}.c 2>/tmp/antiword_v12_aarch64.log
    if [ ! -f /tmp/antiword_v12_$f ]; then
        echo "FAIL: $base (aarch64)"
        grep -E "error:|fatal" /tmp/antiword_v12_aarch64.log | head -3
    fi
done
aarch64-linux-gnu-gcc -s -o /tmp/antiword-v12-aarch64 /tmp/antiword_v12_*.o -lm
ls -la /tmp/antiword-v12-aarch64
file /tmp/antiword-v12-aarch64

# loongarch64 build
echo "===== loongarch64 build ====="
rm -f /tmp/antiword_v12_*.o
for f in $OBJS; do
    base=${f%.o}
    loongarch64-linux-gnu-gcc $CFLAGS -c -o /tmp/antiword_v12_$f ${base}.c 2>/tmp/antiword_v12_loongarch64.log
    if [ ! -f /tmp/antiword_v12_$f ]; then
        echo "FAIL: $base (loongarch64)"
        grep -E "error:|fatal" /tmp/antiword_v12_loongarch64.log | head -3
    fi
done
loongarch64-linux-gnu-gcc -s -o /tmp/antiword-v12-loongarch64 /tmp/antiword_v12_*.o -lm
ls -la /tmp/antiword-v12-loongarch64
file /tmp/antiword-v12-loongarch64
