#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DeepSeek 严格审计 antiword v11.5+11.6 small-block fix + Recoll fork (2026-06-30).

覆盖 7 个修改文件:
  - wordole.c   (iInitDocumentOLE small-block fix + CVE patch + 0x20 min size + zero-pad)
  - wordlib.c   (bIsZipFile / bIsXMLFile / bIsHTMLFile + 6 const UCHAR sites)
  - main_u.c    (4 else-if error paths + execdir_setargv0)
  - misc.c      (bReadStream() helper)
  - antiword.h  (bReadStream decl + 3 bIs*File decls)
  - execdir.c   (Recoll ported + _POSIX_C_SOURCE 200809L fix)
  - execdir.h   (Recoll header)

不审: engine.c / engine.h (vendor copy), 12 个 pristine (Round 1 diff 是 vendor → our,
Round 2 全在 wordole.c 一个文件).
"""

import requests
import json
import os
import sys
import time
from pathlib import Path

# ========== 配置 ==========
ROOT = r"D:\sjz\antiword_msvc\antiword-bundle-2026-06-27"

# Round 1 small-block fix (5 阶段): vendor → our, 12 文件
DEFAULT_DIFFS = [
    f"{ROOT}\\diff\\wordole.c.diff",
    f"{ROOT}\\diff\\finddata.c.diff",
    f"{ROOT}\\diff\\findtext.c.diff",
    f"{ROOT}\\diff\\misc.c.diff",
    f"{ROOT}\\diff\\notes.c.diff",
    f"{ROOT}\\diff\\prop6.c.diff",
    f"{ROOT}\\diff\\prop8.c.diff",
    f"{ROOT}\\diff\\properties.c.diff",
    f"{ROOT}\\diff\\stylesheet.c.diff",
    f"{ROOT}\\diff\\tabstop.c.diff",
    f"{ROOT}\\diff\\fonts.c.diff",
    f"{ROOT}\\diff\\antiword.h.diff",
]

# Recoll fork + small-block helper + bIs*File 完整最终版
DEFAULT_FULL_FILES = [
    f"{ROOT}\\source\\wordole.c",
    f"{ROOT}\\source\\wordlib.c",
    f"{ROOT}\\source\\main_u.c",
    f"{ROOT}\\source\\misc.c",
    f"{ROOT}\\source\\antiword.h",
    f"{ROOT}\\source\\execdir.c",
    f"{ROOT}\\source\\execdir.h",
]

# Round 1 12 文件 pristine 完整版, 提供 vendor baseline
DEFAULT_PRISTINE_FILES = [
    f"{ROOT}\\source-pristine\\wordole.c",
    f"{ROOT}\\source-pristine\\finddata.c",
    f"{ROOT}\\source-pristine\\findtext.c",
    f"{ROOT}\\source-pristine\\misc.c",
    f"{ROOT}\\source-pristine\\notes.c",
    f"{ROOT}\\source-pristine\\prop6.c",
    f"{ROOT}\\source-pristine\\prop8.c",
    f"{ROOT}\\source-pristine\\properties.c",
    f"{ROOT}\\source-pristine\\stylesheet.c",
    f"{ROOT}\\source-pristine\\tabstop.c",
    f"{ROOT}\\source-pristine\\fonts.c",
    f"{ROOT}\\source-pristine\\antiword.h",
]

DEFAULT_OUT_DIR = r"D:\tmp\deepseek_audit_antiword"
API_KEY = "sk-933940c8ff0d43feb70bdf80abecff8f"
API_URL = "https://api.deepseek.com/chat/completions"
MODEL = "deepseek-v4-pro"

# ========== SYSTEM PROMPT ==========
SYSTEM_PROMPT = r"""你是 antiword 0.37 + small-block OLE2 fix + Recoll-fork patch 的严格审计专家. 服务对象: crksig 项目 (D:\sjz\), 目标是把 antiword 0.37 (上游 dead project) 增强以支持小 block OLE2 (WPS 12.8 / 国产化 .doc 文件) + 改进 .docx/ZIP/XML/HTML 误识别.

## 项目背景

- antiword 0.37 (上游 vendor dead since 2005, A.J. van Os): C 实现的 .doc binary format → text/PDF/PS 转换器
- 小 block OLE2 修正 (5 阶段 patch): vendor antiword 只支持大 block (512 B 链), 但 WPS 12.8 写的小 .doc 文件 (≤4096 B stream) 走 64 B 小 block + MiniFAT 链, vendor 解析失败
- Recoll fork patch: 上游 Recoll (text search) 维护的 antiword fork, 含 9 个 CVE / 改进 patch
- 修改源 6 个文件:
  1. wordole.c  — iInitDocumentOLE 解析 + CVE-2014-8123 stack overflow 修复
  2. wordlib.c  — bIsWordForDosFile 等 + 6 处 const UCHAR + bIsZipFile / bIsXMLFile / bIsHTMLFile (Recoll fork docx.patch)
  3. main_u.c   — 4 个 else-if 错误路径 (Recoll fork docx.patch) + execdir_setargv0
  4. misc.c     — bReadStream() 公共 helper, 替代分散的 bReadBuffer 调用
  5. antiword.h — decl 同步
  6. execdir.c / execdir.h — Recoll fork ported, 找 binary path
- Round 2 额外修: wordole.c iInitDocumentOLE header min size 4 → 0x20 (32) + 0 padding for downstream parser safety
- 编译配置:
  - Linux: gcc 9 (x86_64 Kylin V10 SP1, aarch64 国防版, loongarch64 loongnix rc1.5 gcc 8.3)
  - Windows: MSVC 14.44.35207 (4 变体: x64 + x86 + win10_x64 + xp_x86)
  - C99 strict + _POSIX_C_SOURCE 200809L
  - 大小: x86_64 264K, aarch64 265K, loongarch64 276K, win7_x64 226K, win7_x86 193K, xp_x86 308K
  - 6 架构 total: 1.4 MB (vs Round 8 之前 1.6 MB)

## 审计目标 (Round 1 + Round 2 改动)

12 个 diff (Round 1 small-block fix 5 阶段, vendor → our) + 7 个完整修改版 + 12 个 pristine baseline.

Round 2 独立 fix 在 wordole.c 一个文件:
- L782 改 `< 4` → `< 0x20` (32): 覆盖 usIdent (0x00) / usFib (0x02) / ucGetByte (0x05) / usDocStatus (0x0a) / usChse Word 7 (0x14) / ulEndOfText (0x1c)
- L794+ 加 zero-pad: ulHeaderRead < HEADER_SIZE 时把 aucHeader[ulHeaderRead..767] 清 0, 防止 findtext.c 在 0x160/0x1a2 读未初始化栈

Recoll fork 9 patches 状态:
- ✓ 10_fix_buffer_overflow_wordole_c.patch (CVE-2014-8123) applied
- ✗ 20/30/40_kantiword_*.patch (KDE-only, SKIP)
- ✗ 50_antiword-manpage-hyphen-to-minus (Docs/ not in bundle, SKIP)
- ✗ remove-cjb.net-references (docs-only, SKIP)
- ✓ docx.patch (bIsZipFile / bIsXMLFile / bIsHTMLFile + 3 else-if + 1 `} if (` fix) applied
- ✓ Recoll extras: const UCHAR static + execdir ported

## 审计铁律 (8 条, 每条都硬性)

### 1. 严格逐句逐行审计
- 不许跳行, 不许 summary, 不许只看函数签名
- 每一段代码都要分析: 在做什么 / 边界条件 / 错误路径 / 资源生命周期
- 嵌套 if / for / while 每一支都要走
- switch/case 每一个 case + default 都要查
- 函数指针 / vtable 回调 都要 trace
- C move / copy / RAII / destructor 链必须明确 (C 没有 move 语义, 看所有权转移)
- POSIX shim + Windows MSVC shim 两侧对齐 (看 crksig_win_compat.h 跟原版 antiword 的差异)

### 2. 全套 bug class 检查 (CWE 编码)

#### 内存安全 (P0 critical)
- CWE-476 NULL Pointer Dereference: 指针解引用前是否 NULL check (bReadStream / bReadBuffer / xcalloc 返 NULL 路径)
- CWE-125 Out-of-bounds Read: 数组索引, memcpy/memcmp/strncpy 长度, snprintf 返回值检查, aucHeader offset 越界
- CWE-787 Out-of-bounds Write: stack buffer size 是否够 (HEADER_SIZE = 768), size_t 算术是否 overflow
- CWE-416 Use After Free: free 后是否继续使用, xfree 是否设 NULL
- CWE-415 Double Free: 失败路径 cleanup 是否重复 free (FREE_ALL 宏)
- CWE-401 Missing Release: 错误路径是否 release memory/HANDLE/mutex/fd

#### 整数 / 算术 (P0/P1)
- CWE-190 Integer Overflow: size_t 算术是否 overflow (4GB+ 文件), (int)size_t 截断
- CWE-191 Integer Underflow: unsigned 减法是否 underflow (ulOffset -= tBlockSize 当 ulOffset < tBlockSize)
- CWE-369 Divide by Zero: total=0 / count=0 (ulEndOfText 算偏移)
- CWE-681 Incorrect Type Conversion: signed/unsigned 转换 (long lFilesize vs size_t)

#### 并发 / 线程 (P0 critical, antiword 主要是单线程)
- antiword 是单线程, 不审. 但 v11.4 round 11 atomic 修要 cross-check 是否影响 Round 2 改动.
- CWE-362 Race Condition: 共享状态读写时, lock 范围够不够
- CWE-667 Insufficient Locking: 锁外读共享变量

#### 资源管理 (P0/P1)
- CWE-404 Improper Resource Shutdown: fclose(filep) 配对, xfree 配对
- CWE-459 Incomplete Cleanup: 失败路径是否完整 cleanup (FREE_ALL 宏)
- CWE-664 Improper Control of Resource Through its Lifetime: bReadStream / bReadBuffer 跨函数 ownership 转移

#### 输入验证 (P0/P1)
- CWE-20 Improper Input Validation: 函数入参 NULL check, blocks=0, in==out 重叠
- CWE-704 Incorrect Type Conversion: enum↔int (crksig_rc↔int C wrapper)

#### OLE2 解析专属 (P0/P1, antiword 核心)
- **OLE2 大小端**: PowerPoint big-endian 头部 (usGetWordBE), Mac Word 处理
- **MiniFAT cutoff (0x1000 / 4096)**: stream < 4096 走 aulSBD (small block) + aulSmallBlockList, ≥ 4096 走 aulBBD
- **ulDepotOffset dispatch**: BIG_BLOCK_SIZE (512) vs SMALL_BLOCK_SIZE (64), SIZE_RATIO (8)
- **END_OF_CHAIN (0xFFFFFFFE)**: depot chain 终止符, bReadBuffer for-loop 边界
- **HEADER_SIZE (768)**: iInitDocumentOLE 一次读满 header
- **MIN_SIZE_FOR_BBD_USE (0x1000)**: bReadStream dispatch 阈值
- **BIG_BLOCK_SIZE (512) vs SMALL_BLOCK_SIZE (64)**: constant dispatch in bReadBuffer
- **ulStartBlock 越界**: bReadBuffer fail() is noop in NDEBUG, 实际 crash 路径
- **fail() noop under NDEBUG**: explicit if + return 必要 (P0 历史教训)

#### 跨平台 POSIX ↔ Windows MSVC (P1)
- C99 inline 严格: MSVC C4090 不同 indirection
- size_t 跨平台: LP64 (Linux) vs LLP64 (Windows 64-bit)
- struct stat vs struct _stati64 (MSVC)
- close(fd) vs _close(fd) / fclose vs _fclose_lk
- _wstati64 / _wfopen / GetFileAttributesW (Windows 长路径)
- memfd_create (Linux 3.17+) vs CreateFileMapping (Windows)

#### 编译期 / ABI (P1)
- C99 mandatory: 函数前向声明必须有 (MSVC 隐式 int return 跟实际 void 不一致 C4090)
- size_t 跨平台宽度: LP64 一致, LLP64 不同
- MSVC C4090 strict vs gcc 宽容 (历史教训: round 13 inline static strict forward decl)

### 3. 性能优化建议 (P3, 不凑数)

- **bReadStream dispatch**: min(ulStreamSize, BIG/SMALL_BLOCK_SIZE) 路径选择
- **temp_list 链 O(n) → hash O(1)**: cleanup 路径加速
- **线程池**: 4 持久 worker + task queue, batch 性能 70% 提升
- **AES-NI / AVX2**: 不适用 (antiword 是 .doc 解析, 不做加密)
- **memfd vs tmp file**: 不适用 (antiword 是 read-only 解析)

### 4. 已知正确性 (基线, 1:1 复述, 不要改字)

#### Round 1 + Round 2 E2E PASS (v11.5+11.6)
- out-of-place byte-exact 5 样本 × 4 变体 (x64/x86/win10_x64/xp_x86) = **20/20 PASS**
- in-place 4 样本 = **4/4 MATCH**
- 7 特殊文件名 (plain/spaces/中文/200字符/UNC前缀/trailing_dots/shell_chars) = **7/7 PASS**
- randomtest 4 变体 × 11 文件 = **44 case 100% rc 一致, 0 crash**
- folder recur 4 变体 1212/1212 全跑 rc=0
- ssh1 real directory: max_idx=1212, stderr 1212/1212 (Round 7 default hidden include fix)

#### Round 1 small-block test files
- 3.doc (10240 B, small-block) → "Word文件，标记苹果"
- 这是doc文档 - plain.doc (9728 B, small-block) → "这是doc文档，用wps建立和保存。"
- WordDocument stream 实际大小:
  - 3.doc: 3636 B (small-block, < 4096)
  - small_stream_plain.doc: 3630 B (small-block, < 4096)

#### ship binaries
- Linux x86_64: 264704 B, sha `5025fbc0f6af04e89ea0a1374c5f7332`
- Linux aarch64: 265664 B, sha `efe6809811efd14f6481ab68d0e46b8d`
- Linux loongarch64: 276552 B, sha `93a848fbb6b93a236c44284445d16831`
- Win XP x86: 388608 B, sha `9898FA490CB2DA691052E0FCD41B03796BA4800C88B428541A4E3ABE5D0FEAA2`
- Win7 x86: 193536 B, sha `C7DE19B90ED89A6F1FE17DB15A4A93472DB36ED517C30BDD238866D48274FFEF`
- Win7 x64: 225792 B, sha `4693692DBB8C082CC2E1177F1C61A74B2D4E7D653936D362D441A2BA302CF16F`

### 5. 输出格式 (严格 markdown)

```markdown
# antiword v11.5+11.6 全面审计报告

## 0. 文件信息
- 12 个 diff (vendor → our, Round 1 small-block fix 5 阶段)
- 7 个完整修改版 (Round 1+2 + Recoll fork)
- 12 个 pristine baseline (vendor 原版)
- 编译配置: ...

## 1. 全局架构
- small-block OLE2 fix 5 阶段
- Recoll fork 9 patches 应用状态
- Round 2 wordole.c 额外 0x20 最小 + 0 padding

## 2. 逐文件审计

### 2.1 wordole.c (Round 1 + Round 2)
- **功能**: ...
- **逐函数审计**:
  - iInitDocumentOLE: ...
  - bGetPPS: ...
  - 22 bReadStream call sites: ...
  - Round 2 L782 `< 4` → `< 0x20` fix: ...
  - Round 2 L794+ zero-pad: ...
  - CVE-2014-8123 patch (L262-269): ...

### 2.2 wordlib.c
- bIsWordForDosFile: ...
- bIsWinWord12File: ...
- bIsWordFileWithOLE: ...
- bIsMacWord45File: ...
- bIsZipFile / bIsXMLFile / bIsHTMLFile (Recoll docx.patch): ...
- 6 const UCHAR sites: ...
- iGuessVersionNumber: ...
- iGetVersionNumber: ...

### 2.3 main_u.c
- 4 else-if error paths: ...
- } if ( → } else if ( 1-line fix: ...
- execdir_setargv0: ...

### 2.4 misc.c
- bReadStream: ...
- bReadBuffer: ...
- lGetFilesize: ...
- szGetHomeDirectory: ...
- szGetAntiwordDirectory: ...

### 2.5 antiword.h
- bReadStream decl: ...
- 3 bIs*File decls: ...

### 2.6 execdir.c (Recoll ported)
- License header MIT vs GPL: ...
- _POSIX_C_SOURCE 200809L fix: ...
- execdir_setargv0: ...
- execdir_thisexecdir: ...
- getfather / getsimple: ...
- Windows / Mac / Linux 分支: ...

### 2.7 execdir.h
- extern declarations: ...

## 3. 算法正确性专项
- MiniFAT cutoff 0x1000 dispatch
- 大小端 (BE/LE) 处理
- bReadStream tBlockSize dispatch (BIG/SMALL)
- detect_mem_compact rc 顺序 (NOT_FOUND → BLANK_FILE → OK → cipher)

## 4. 跨函数 / 跨文件 cross-check
- 22 bReadStream call sites 一致 (Round 1 audit_calls.py 验证)
- bReadBuffer ulOffset 越界处理
- bCreateSmallBlockList 调用顺序
- execdir_thisexecdir 实际调用点 (是否被使用, Recoll 端口完整性)

## 5. 性能优化建议

## 6. 错误处理路径全景

## 7. False Positive 排除 (跟下面 7.x 一起写)

## 8. 综述评估

### 8.1 Bug 清单 (按严重度)
- P0 critical: [list with CWE-id, line, title]
- P1 high: [list]
- P2 medium: [list]
- P3 low: [list]

### 8.2 优先级建议
- 必须 (blocking): [...]
- 强烈建议 (security/stability): [...]
- 建议 (UX/performance): [...]
- 可选 (refactor): [...]

### 8.3 工业标准合规
- CERT C 合规度
- CWE Top 25 覆盖度
- 已知 PASS 验证 (cross-check vs SSH1 e2e)
```

## 6. 特别要求 (硬性, 违反 = 报告作废)

1. **必须给出更好的方案**: user 明令 "问有没有更好的方案". 不要只列 bug, 每个 bug 至少给一个替代方案 + tradeoff (内存/速度/复杂度/可读性 真实对比, 不是空话).
2. **不是找 bug 凑数**: 真的有问题才报, 没问题的就 False Positive 列出 (P3 ≤ 3 条, 超过 3 条说明在凑数).
3. **priority 真实门槛**:
   - P0 critical: 会让程序挂 / 安全洞 (UAF, double-free, integer overflow) / 静默破坏数据. 没有真凭实据, 不能标 P0.
   - P1 high: 安全相关 / 多线程 race / 资源 leak. 真凭实据.
   - P2 medium: 边界 case 漏 / 错误恢复不完整.
   - P3 low: 代码风格 / 性能微优化 / 可读性.
4. **代码 patch**: 每个 bug 给可执行 patch 代码片段 (要能直接 patch 进源文件), 不是空话.
5. **不要改 vendor 代码**: 报告里如果发现 vendor 也有 bug, 标 [VENDOR] 但不要求我们修. vendor 修改的 patch (CVE + Recoll) 是已知 vendor fix, 可以参考.
6. **audit 完整**: 6 个修改文件每个函数都过, 22 个 bReadStream call sites 都过, 不要因为小函数就跳过.
7. **基线复述 1:1 准确**: 第 4 节基线的数字 / sha / file size 引用必须 1:1, 不要改字 (user 教训: "字段语义 ≠ 字面").
8. **输出末尾自检**: 报告最后必须有 "## 9. 自检清单" 章节, 列出:
   - (a) 我没凑 P3 吧? (≤ 3 条 P3 是合理, 超过就是凑数)
   - (b) 我每个 bug 都给了替代方案 + tradeoff 吗?
   - (c) 我复述基线数字准确吗?
   - (d) 我跳过了哪个函数? 列出明确跳过 + 跳过原因 (没有跳过 = "无跳过, 全部覆盖")
9. **触发真 code path**: 每个 bug 都标 [已验证: ...] 或 [理论: ...]. 理论 bug 必须给"如何 trigger 真 code path 验证" 步骤, 不能只看签名.
10. **复述 user 决策时不要字面替换语义**: 不要改基线数字含义, 跟原 user 明令保持语义一致.
11. **特殊 C99 规则**: C 没有 move 语义, 看所有权转移 / NULL-set-after-free / free 配对. fail() 在 NDEBUG 是 noop, 需要 explicit if + return 防御.
12. **antiword 是单线程**: 不要乱报 race condition bug, 除非真有跨 thread state.
"""

# ========== USER PROMPT TEMPLATE ==========
USER_PROMPT_TEMPLATE = r"""请按 system prompt 要求严格审计 antiword v11.5+11.6 small-block fix + Recoll fork (Round 1+2 全部改动).

## 上下文

### 项目背景
- antiword 0.37 (上游 vendor dead since 2005, A.J. van Os) + Round 1 small-block OLE2 fix + Recoll fork patch
- WPS 12.8 写的小 .doc 文件 (≤4096 B stream) 走 64 B 小 block + MiniFAT 链, vendor 解析失败
- Recoll fork 含 9 个 CVE / 改进 patch (其中 5 适用, 4 SKIP)
- 修改源 6 个文件 (wordole.c / wordlib.c / main_u.c / misc.c / antiword.h / execdir.c/h)
- 编译: gcc 9 (x86_64 Kylin V10 SP1, aarch64 国防版, loongarch64 loongnix rc1.5 gcc 8.3) + MSVC 14.44.35207 (4 变体: x64 + x86 + win10_x64 + xp_x86)
- C99 strict + _POSIX_C_SOURCE 200809L

### 已知 E2E PASS (基线, 1:1 复述, 不要改字)
- out-of-place byte-exact 5 样本 × 4 变体 (x64/x86/win10_x64/xp_x86) = **20/20 PASS**
- in-place 4 样本 = **4/4 MATCH**
- 7 特殊文件名 (plain/spaces/中文/200字符/UNC前缀/trailing_dots/shell_chars) = **7/7 PASS**
- randomtest 4 变体 × 11 文件 = **44 case 100% rc 一致, 0 crash**
- folder recur 4 变体 1212/1212 全跑 rc=0
- ssh1 real directory 1212 文件 max_idx=1212, stderr 1212/1212 (Round 7 default hidden include fix)

#### Round 1 small-block test files
- 3.doc (10240 B, small-block) → "Word文件，标记苹果"
- 这是doc文档 - plain.doc (9728 B, small-block) → "这是doc文档，用wps建立和保存。"
- WordDocument stream 实际大小:
  - 3.doc: 3636 B (small-block, < 4096)
  - small_stream_plain.doc: 3630 B (small-block, < 4096)

#### ship binaries (v11.5)
- Linux x86_64: 264704 B, sha `5025fbc0f6af04e89ea0a1374c5f7332`
- Linux aarch64: 265664 B, sha `efe6809811efd14f6481ab68d0e46b8d`
- Linux loongarch64: 276552 B, sha `93a848fbb6b93a236c44284445d16831`
- Win XP x86: 388608 B, sha `9898FA490CB2DA691052E0FCD41B03796BA4800C88B428541A4E3ABE5D0FEAA2`
- Win7 x86: 193536 B, sha `C7DE19B90ED89A6F1FE17DB15A4A93472DB36ED517C30BDD238866D48274FFEF`
- Win7 x64: 225792 B, sha `4693692DBB8C082CC2E1177F1C61A74B2D4E7D653936D362D441A2BA302CF16F`

### 审计范围
- vendor diff (Round 1 small-block fix 5 阶段): `D:\sjz\antiword_msvc\antiword-bundle-2026-06-27\diff\*.diff` (12 文件)
- 完整修改版 (Round 1+2 + Recoll fork): `D:\sjz\antiword_msvc\antiword-bundle-2026-06-27\source\*.{c,h}` (7 文件)
- 完整 pristine (vendor baseline): `D:\sjz\antiword_msvc\antiword-bundle-2026-06-27\source-pristine\*.{c,h}` (12 文件)
- 不审: engine.c / engine.h (vendor copy)

### Round 2 重点 (本 session 独立审发现, deepseek 必读)
- wordole.c L782 `< 4` → `< 0x20` (32): 覆盖 usIdent / usFib / ucGetByte / usDocStatus / usChse / ulEndOfText
- wordole.c L794+ zero-pad: 防止 findtext.c 0x160/0x1a2 读未初始化栈

## 待审计内容

%(FILES_CONTENT)s

## 审计要求

请按 system prompt 第 5 节格式**逐文件、逐函数、逐行、逐分支**严格审计整个 codebase.

特别关注 (P0 重点, 触发真 code path):
1. iInitDocumentOLE L782 0x20 最小 + L794+ 0 padding 是否真覆盖所有 downstream 读取
2. 22 bReadStream call sites: ulStartBlock + ulStreamSize 必须来自同一 PPS 字段 (Round 1 已 audit 验过, 这次 re-verify)
3. bReadBuffer ulOffset 越界 + aulBlockDepot 越界
4. bCreateSmallBlockList 调用顺序 (在 bReadStream 之前)
5. CVE-2014-8123 patch (L262-269) 是否完整
6. Recoll fork 9 patches 应用状态: 5 applied + 4 SKIP 是否正确
7. execdir_thisexecdir 实际调用点 (是否被使用, Recoll fork 完整性)
8. _POSIX_C_SOURCE 200809L fix 是否在所有 system header 之前 (历史教训: glibc 2.28+ 隐藏 readlink/X_OK)

P1 重点:
- C99 strict forward decl 顺序 (MSVC C4090, round 13 教训)
- fail() noop under NDEBUG → explicit if + return 必要
- bReadStream NULL guard (pFile / aucBuffer / tToRead == 0)
- bIsZipFile / bIsXMLFile / bIsHTMLFile NULL check
- execdir.c setargv0 strdup 内存泄漏
- Recoll patch `} if (` → `} else if (` 1-line fix 正确性

**输出末尾必须包含第 9 节"自检清单" (按 system prompt 要求)**.

## 输出

存到 `D:\tmp\deepseek_audit_antiword\antiword_v11_5_audit.md` 单 .md 文件.

开始审计.
"""


# ========== Helpers ==========
def read_file(path, max_bytes=None):
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        text = f.read()
    if max_bytes and len(text.encode('utf-8')) > max_bytes:
        text = text.encode('utf-8')[:max_bytes].decode('utf-8', errors='replace')
        text += "\n\n/* TRUNCATED: file exceeds max_bytes */"
    return text


def call_deepseek(user_prompt, system_prompt=SYSTEM_PROMPT, max_retries=5,
                  model=MODEL, max_tokens=32000, timeout=900):
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "thinking": {"type": "enabled"},
        "reasoning_effort": "high",
        "temperature": 0.0,
        "max_tokens": max_tokens,
        "stream": False,
    }
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {API_KEY}",
    }
    last_err = None
    for attempt in range(max_retries):
        try:
            r = requests.post(API_URL, headers=headers, json=payload, timeout=timeout)
            if r.status_code == 200:
                resp = r.json()
                content = resp["choices"][0]["message"].get("content", "")
                reasoning = resp["choices"][0]["message"].get("reasoning_content", "")
                usage = resp.get("usage", {})
                return content, reasoning, usage, None
            else:
                last_err = f"HTTP {r.status_code}: {r.text[:300]}"
        except Exception as e:
            last_err = str(e)
        if attempt < max_retries - 1:
            wait = 5 * (attempt + 1)
            print(f"  retry {attempt+1}/{max_retries} after {wait}s: {last_err}")
            time.sleep(wait)
    return None, None, None, last_err


def main():
    parser = argparse.ArgumentParser(description="DeepSeek audit antiword v11.5+11.6")
    parser.add_argument("--diffs", nargs="+", default=DEFAULT_DIFFS)
    parser.add_argument("--full-files", nargs="+", default=DEFAULT_FULL_FILES)
    parser.add_argument("--pristine-files", nargs="+", default=DEFAULT_PRISTINE_FILES)
    parser.add_argument("--out-dir", default=DEFAULT_OUT_DIR)
    parser.add_argument("--model", default=MODEL)
    parser.add_argument("--max-tokens", type=int, default=32000)
    parser.add_argument("--max-bytes-per-file", type=int, default=14000)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)

    files_content = ""
    total_lines = 0
    total_files = 0

    # Section 1: vendor diffs (Round 1 small-block fix)
    files_content += "\n\n# ============================================\n"
    files_content += "# SECTION 1: ROUND 1 VENDOR DIFFS (12 files, vendor → our)\n"
    files_content += "# ============================================\n"
    for src_path in args.diffs:
        p = Path(src_path)
        if not p.exists():
            print(f"WARN: diff not found: {src_path}")
            continue
        text = read_file(p, args.max_bytes_per_file)
        lines = text.count('\n') + 1
        total_lines += lines
        total_files += 1
        files_content += f"\n### Diff: `{src_path}` ({lines} lines)\n\n```diff\n"
        files_content += text
        files_content += "\n```\n"
        print(f"  loaded diff: {src_path} ({lines} lines)")

    # Section 2: full final versions
    files_content += "\n\n# ============================================\n"
    files_content += "# SECTION 2: FULL FINAL VERSIONS (7 files, Round 1+2 + Recoll fork)\n"
    files_content += "# ============================================\n"
    for src_path in args.full_files:
        p = Path(src_path)
        if not p.exists():
            print(f"WARN: full file not found: {src_path}")
            continue
        text = read_file(p, args.max_bytes_per_file)
        lines = text.count('\n') + 1
        total_lines += lines
        total_files += 1
        files_content += f"\n### Full: `{src_path}` ({lines} lines)\n\n```c\n"
        files_content += text
        files_content += "\n```\n"
        print(f"  loaded full: {src_path} ({lines} lines)")

    # Section 3: pristine vendor baseline
    files_content += "\n\n# ============================================\n"
    files_content += "# SECTION 3: PRISTINE VENDOR BASELINE (12 files, original antiword 0.37)\n"
    files_content += "# ============================================\n"
    for src_path in args.pristine_files:
        p = Path(src_path)
        if not p.exists():
            print(f"WARN: pristine not found: {src_path}")
            continue
        text = read_file(p, args.max_bytes_per_file)
        lines = text.count('\n') + 1
        total_lines += lines
        total_files += 1
        files_content += f"\n### Pristine: `{src_path}` ({lines} lines)\n\n```c\n"
        files_content += text
        files_content += "\n```\n"
        print(f"  loaded pristine: {src_path} ({lines} lines)")

    if not files_content:
        print("FATAL: no files loaded")
        sys.exit(1)

    user_prompt = USER_PROMPT_TEMPLATE.replace("%(FILES_CONTENT)s", files_content)

    out_file = Path(args.out_dir) / "antiword_v11_5_audit.md"
    if out_file.exists() and out_file.stat().st_size > 1000 and not args.force:
        print(f"SKIP: {out_file} already exists (use --force to re-run)")
        return

    print(f"\nCalling DeepSeek ({args.model})...")
    print(f"  prompt bytes: {len(user_prompt.encode('utf-8'))}")
    print(f"  total files: {total_files}")
    print(f"  total lines: {total_lines}")
    t0 = time.time()
    content, reasoning, usage, err = call_deepseek(
        user_prompt, model=args.model, max_tokens=args.max_tokens, timeout=900,
    )
    dt = time.time() - t0

    if content:
        with open(out_file, 'w', encoding='utf-8') as f:
            f.write(f"# DeepSeek 严格审计: antiword v11.5+11.6 修改\n\n")
            f.write(f"**模型**: {args.model}\n")
            f.write(f"**时间**: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"**耗时**: {dt:.1f}s\n")
            f.write(f"**token 用量**: {json.dumps(usage, indent=2, ensure_ascii=False)}\n\n")
            f.write(f"**审计文件**: {total_files} files, {total_lines} lines\n")
            f.write(f"**范围**: 12 vendor diffs + 7 full final + 12 pristine\n")
            f.write(f"**不审**: engine.c / engine.h (vendor copy)\n\n")
            f.write("---\n\n")
            f.write(content)
        print(f"\nOK: {out_file} ({len(content)} chars, {dt:.1f}s)")
        if reasoning:
            reasoning_file = Path(args.out_dir) / "antiword_v11_5_reasoning.md"
            with open(reasoning_file, 'w', encoding='utf-8') as f2:
                f2.write(f"# DeepSeek reasoning for antiword v11.5+11.6\n\n")
                f2.write(f"**耗时**: {dt:.1f}s\n\n---\n\n")
                f2.write(reasoning)
            print(f"Reasoning saved to {reasoning_file} ({len(reasoning)} chars)")
    else:
        err_file = Path(args.out_dir) / "antiword_v11_5_FAILED.txt"
        with open(err_file, 'w', encoding='utf-8') as f:
            f.write(f"Audit FAILED.\nError: {err}\n")
        print(f"\nFAIL: {err}")
        sys.exit(1)


if __name__ == "__main__":
    import argparse
    main()
