cd /tmp/antiword-v12-build
rm -f /tmp/antiword_v12_*.o

OBJS="
main_u.o asc85enc.o blocklist.o chartrans.o datalist.o depot.o
dib2eps.o doclist.o fail.o finddata.o findtext.o fmt_text.o fontlist.o
fonts.o fonts_u.o hdrftrlist.o imgexam.o imgtrans.o jpeg2eps.o
listlist.o misc.o notes.o options.o out2window.o output.o pdf.o
pictlist.o png2eps.o postscript.o prop0.o prop2.o prop6.o prop8.o
properties.o propmod.o rowlist.o sectlist.o stylelist.o stylesheet.o
summary.o tabstop.o text.o unix.o utf8.o word2text.o worddos.o
wordlib.o wordmac.o wordole.o wordwin.o xmalloc.o xml.o
execdir.o
"

# Use CFLAGS without the macro expansion problem
for f in $OBJS; do
    base=${f%.o}
    gcc -D_POSIX_C_SOURCE=200809L -DNDEBUG -DUNIX -DGLOBAL_ANTIWORD_DIR='"/usr/share/antiword/"' -I. -O2 -c -o /tmp/antiword_v12_$f ${base}.c 2>&1 | grep -E "error:|fatal" | head -3
done

gcc -s -o /tmp/antiword-v12-build/antiword /tmp/antiword_v12_*.o -lm 2>&1 | tail -10
echo "BUILD EXIT: $?"

if [ -f /tmp/antiword-v12-build/antiword ]; then
    ls -la /tmp/antiword-v12-build/antiword
    md5sum /tmp/antiword-v12-build/antiword
    file /tmp/antiword-v12-build/antiword
fi
