@echo off
setlocal enabledelayedexpansion

set ROOT=%~dp0
set SRC=%ROOT%antiword-bundle-2026-06-27\source
set RES=%ROOT%antiword_res
set VCVARS_BASE=C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build
set VCVARS32=%VCVARS_BASE%\vcvars32.bat
set VCVARS64=%VCVARS_BASE%\vcvars64.bat

REM Default: x64 env
call "%VCVARS64%" >nul 2>&1

REM Setup resources
if not exist "%RES%\8859-1.txt" (
    mkdir "%RES%"
    xcopy /Y /Q "%SRC%\Resources\*" "%RES%\" >nul
)
if not exist "%SRC%\version.h" echo #define VERSION "0.37 + small-block fix v11.6" > "%SRC%\version.h"

set SOURCES=asc85enc.c blocklist.c chartrans.c datalist.c depot.c dib2eps.c doclist.c fail.c finddata.c findtext.c fmt_text.c fontlist.c fonts.c fonts_u.c getopt_msvc.c hdrftrlist.c imgexam.c imgtrans.c jpeg2eps.c listlist.c main_u.c misc.c notes.c options.c out2window.c output.c pdf.c pictlist.c png2eps.c postscript.c prop0.c prop2.c prop6.c prop8.c properties.c propmod.c rowlist.c sectlist.c stylelist.c stylesheet.c summary.c tabstop.c text.c unix.c utf8.c word2text.c worddos.c wordlib.c wordmac.c wordole.c wordwin.c xmalloc.c xml.c

REM ===== Variant: XP x86 =====
echo.
echo ============ Building XP x86 ============
REM Use vcvars32 for IA32 (/arch:IA32 only valid in x86 env)
call "%VCVARS32%" >nul 2>&1

set OUT=%ROOT%out_xp_x86
set OBJS_DIR=%OUT%\obj
if exist "%OUT%" rd /s /q "%OUT%"
mkdir "%OBJS_DIR%"

set CFLAGS=/nologo /c /O2 /arch:IA32 /D_CRT_SECURE_NO_WARNINGS /D__CYGMING__ /DNDEBUG /DWIN32 /D_WIN32_WINNT=0x0501 /DWINVER=0x0501 /MT /utf-8 /I"%SRC%" /W3 /Gy /Gw /GF /Zp4
set LINKFLAGS=/nologo /SUBSYSTEM:CONSOLE,5.01 /LTCG /OPT:REF /OPT:ICF /DYNAMICBASE:NO /INCREMENTAL:NO /MERGE:.rdata=.text /OUT:"%OUT%\antiword.exe" kernel32.lib user32.lib advapi32.lib

for %%f in (%SOURCES%) do (
    cl %CFLAGS% /Fo"%OBJS_DIR%\%%~nf.obj" "%SRC%\%%f"
)

set OBJS=
for %%f in (%SOURCES%) do set OBJS=!OBJS! "%OBJS_DIR%\%%~nf.obj"

link %LINKFLAGS% %OBJS%
if errorlevel 1 exit /b 1

del /Q "%OBJS_DIR%\*.pdb" "%OBJS_DIR%\*.log" 2>nul
echo XP x86: !ERRORLEVEL!
dir "%OUT%\antiword.exe" | findstr antiword.exe

REM ===== Variant: Win7 x86 =====
echo.
echo ============ Building Win7 x86 ============
REM Stay in vcvars32 from XP build (still need x86 for /arch:SSE2 SSE2 codegen)
set OUT=%ROOT%out_win7_x86
set OBJS_DIR=%OUT%\obj
if exist "%OUT%" rd /s /q "%OUT%"
mkdir "%OBJS_DIR%"

set CFLAGS=/nologo /c /O2 /arch:SSE2 /D_CRT_SECURE_NO_WARNINGS /D__CYGMING__ /DNDEBUG /DWIN32 /D_WIN32_WINNT=0x0601 /DWINVER=0x0601 /MD /utf-8 /I"%SRC%" /W3 /Gy /Gw /GF /Zp4
set LINKFLAGS=/nologo /SUBSYSTEM:CONSOLE,6.01 /LTCG /OPT:REF /OPT:ICF /DYNAMICBASE:NO /INCREMENTAL:NO /MERGE:.rdata=.text /OUT:"%OUT%\antiword.exe" kernel32.lib user32.lib advapi32.lib

for %%f in (%SOURCES%) do (
    cl %CFLAGS% /Fo"%OBJS_DIR%\%%~nf.obj" "%SRC%\%%f"
)

set OBJS=
for %%f in (%SOURCES%) do set OBJS=!OBJS! "%OBJS_DIR%\%%~nf.obj"

link %LINKFLAGS% %OBJS%
if errorlevel 1 exit /b 1

del /Q "%OBJS_DIR%\*.pdb" "%OBJS_DIR%\*.log" 2>nul
echo Win7 x86: !ERRORLEVEL!
dir "%OUT%\antiword.exe" | findstr antiword.exe

REM ===== Variant: Win7 x64 =====
echo.
echo ============ Building Win7 x64 ============
REM Switch back to vcvars64 for native x64 build
call "%VCVARS64%" >nul 2>&1

set OUT=%ROOT%out_win7_x64
set OBJS_DIR=%OUT%\obj
if exist "%OUT%" rd /s /q "%OUT%"
mkdir "%OBJS_DIR%"

set CFLAGS=/nologo /c /O2 /D_CRT_SECURE_NO_WARNINGS /D__CYGMING__ /DNDEBUG /DWIN32 /D_WIN32_WINNT=0x0601 /DWINVER=0x0601 /MD /utf-8 /I"%SRC%" /W3 /Gy /Gw /GF /Zp4
set LINKFLAGS=/nologo /SUBSYSTEM:CONSOLE,6.01 /LTCG /OPT:REF /OPT:ICF /DYNAMICBASE:NO /INCREMENTAL:NO /MERGE:.rdata=.text /OUT:"%OUT%\antiword.exe" kernel32.lib user32.lib advapi32.lib

for %%f in (%SOURCES%) do (
    cl %CFLAGS% /Fo"%OBJS_DIR%\%%~nf.obj" "%SRC%\%%f"
)

set OBJS=
for %%f in (%SOURCES%) do set OBJS=!OBJS! "%OBJS_DIR%\%%~nf.obj"

link %LINKFLAGS% %OBJS%
if errorlevel 1 exit /b 1

del /Q "%OBJS_DIR%\*.pdb" "%OBJS_DIR%\*.log" 2>nul
echo Win7 x64: !ERRORLEVEL!
dir "%OUT%\antiword.exe" | findstr antiword.exe

echo.
echo ============ ALL 3 BUILDS COMPLETE ============
endlocal
