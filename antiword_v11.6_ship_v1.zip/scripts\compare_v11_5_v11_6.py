#!/usr/bin/env python3
"""Byte-level diff v11.5 baseline (results/) vs v11.6 new build (test_<variant>/)"""
import os
import sys
import hashlib
from pathlib import Path

results_dir = Path(r"D:\sjz\antiword_msvc\test_docs\results")
test_dirs = {
    "xp_x86":   Path(r"D:\tmp\test_xp_x86"),
    "win7_x86": Path(r"D:\tmp\test_win7_x86"),
    "win7_x64": Path(r"D:\tmp\test_win7_x64"),
}

# Map baseline filename to new build filename (after re-encoding safe)
mapping = [
    ("3.doc.txt",                   "xp_x86_3.doc.txt"),
    ("3.doc.txt",                   "win7_x86_3.doc.txt"),
    ("3.doc.txt",                   "win7_x64_3.doc.txt"),
    ("CUPT_lf.txt",                 "xp_x86_CUPT_lf.txt"),
    ("3.doc.txt",                   None),  # no CUPT_lf in new
    ("small.doc.txt",               "xp_x86_small_stream_plain.doc.txt"),
]

# Get baseline file MD5s
print("=== BASELINE ===")
for f in sorted(results_dir.glob("*.txt")):
    h = hashlib.md5(f.read_bytes()).hexdigest()
    print(f"  {f.name} (size={f.stat().st_size}) md5={h}")

# Compare
for variant, new_dir in test_dirs.items():
    print(f"\n=== {variant} ===")
    for f in sorted(new_dir.glob("*.txt")):
        h = hashlib.md5(f.read_bytes()).hexdigest()
        print(f"  {f.name} (size={f.stat().st_size}) md5={h}")

# Find baseline files with same name as new files
print("\n=== PAIR COMPARISON ===")
for new_file in test_dirs["xp_x86"].glob("*.txt"):
    # Find baseline with same content (search by md5)
    new_md5 = hashlib.md5(new_file.read_bytes()).hexdigest()
    new_size = new_file.stat().st_size
    for baseline_file in results_dir.glob("*.txt"):
        b_md5 = hashlib.md5(baseline_file.read_bytes()).hexdigest()
        b_size = baseline_file.stat().st_size
        if b_md5 == new_md5:
            print(f"  {new_file.name} ({new_size}B) == {baseline_file.name} ({b_size}B) (md5 match)")
            break
    else:
        # Try size + content match for different encodings
        for baseline_file in results_dir.glob("*.txt"):
            b_size = baseline_file.stat().st_size
            if b_size == new_size:
                b_content = baseline_file.read_bytes()
                n_content = new_file.read_bytes()
                if b_content.replace(b' ', b'').replace(b'\r', b'') == n_content.replace(b' ', b'').replace(b'\r', b''):
                    print(f"  {new_file.name} ({new_size}B) ~= {baseline_file.name} ({b_size}B) (content match, encoding diff)")
                    break
        else:
            # Show size diff
            closest = min(results_dir.glob("*.txt"), key=lambda f: abs(f.stat().st_size - new_size))
            print(f"  {new_file.name} ({new_size}B) != closest baseline {closest.name} ({closest.stat().st_size}B) (NO match)")
