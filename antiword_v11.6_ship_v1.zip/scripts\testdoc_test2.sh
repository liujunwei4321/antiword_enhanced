#!/bin/bash
# Quick test of plain.doc
cd /home/test/桌面/testdoc/

echo "===== antiword v11.6 v12 testdoc/ folder test ====="
echo ""

# Just run plain.doc to verify
echo "Test 1: 这是doc文档 - plain.doc (small-block)"
env ANTIWORDHOME=/usr/share/antiword LANG=zh_CN.UTF-8 /tmp/antiword-v12-build/antiword -t -m UTF-8.txt "这是doc文档 - plain.doc"
echo "RC: $?"
echo ""

echo "Test 2: CUPT介绍.doc (big-block)"
env ANTIWORDHOME=/usr/share/antiword LANG=zh_CN.UTF-8 /tmp/antiword-v12-build/antiword -t -m UTF-8.txt "CUPT介绍.doc" | head -3
echo ""
echo "Test 3: plaindocx.docx (should report ZIP)"
env ANTIWORDHOME=/usr/share/antiword LANG=zh_CN.UTF-8 /tmp/antiword-v12-build/antiword -t -m UTF-8.txt "plaindocx.docx" 2>&1
echo "RC: $?"
