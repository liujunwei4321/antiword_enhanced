/* Copyright (C) 2026 J.F.Dockes
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/* Mavis: feature test macros MUST be defined BEFORE any system header is
 * included, otherwise glibc 2.28+ won't expose readlink() / access() / X_OK
 * (they require _POSIX_C_SOURCE >= 200809L). The include of execdir.h
 * below transitively pulls in stdlib.h which would otherwise lock in
 * _DEFAULT_SOURCE without _POSIX_C_SOURCE. */
#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif

#include "execdir.h"

#include <string.h>
#include <stdio.h>
/* Mavis: needed for readlink() / access() / X_OK / PATH_MAX (Recoll's
 * original execdir.c was missing these; the code worked on glibc systems
 * where _DEFAULT_SOURCE pulled them in transitively, but is fragile). */
#include <unistd.h>
#include <limits.h>

static void getfather(char *path)
{
    char *slash = strrchr(path, '/');
    if (slash) {
        *(slash+1) = 0;
    }
}

const char *getsimple(const char *path)
{
    char *slash = strrchr(path, '/');
    if (slash == 0)
        return path;
    return slash + 1;
}


#ifdef _WIN32
#include <Shlwapi.h>
#pragma comment(lib, "shlwapi.lib")

size_t wchartoutf8(const wchar_t *in, size_t wlen, char *out, size_t outlen)
{
    char *buffer;
    int flags = WC_ERR_INVALID_CHARS;
    int bytes;
    
    if (in == 0) {
        return 0;
    }

    /* If input length was not given, compute it. */
    if (wlen == 0) {
        wlen = wcslen(in);
    }
    /* WideCharToMultiByte with 0 output buffer and length to get the actual needed length */
    flags = WC_ERR_INVALID_CHARS;
    bytes = ::WideCharToMultiByte(CP_UTF8, flags, in, wlen, nullptr, 0, nullptr, nullptr);
    if (bytes <= 0) {
        fwprintf(stderr, L"wchartoutf8: conversion error1 for [%s]\n", in);
        return 0;
    }
    /* If we were called to compute the length, return it. If we were called with a small buffer,
       return an error. */
    if (outlen == 0 || out == 0) {
        return bytes + 1;
    } else if (outlen < bytes + 1) {
        return 0;
    }

    /* Perform the conversion */
    bytes = ::WideCharToMultiByte(CP_UTF8, flags, in, wlen, out, outlen, nullptr, nullptr);
    if (bytes <= 0) {
        fprintf(stderr, "wchartoutf8: WideCharToMultiByte (actual) failed\n");
        return 0;
    }
    out[bytes] = 0;
    return bytes+1;
}

char *execdir_thisexecdir()
{
    wchar_t text[MAX_PATH];
    char *path;
    size_t pathlen;

    GetModuleFileNameW(NULL, text, MAX_PATH);
#ifdef NTDDI_WIN8_future
    PathCchRemoveFileSpec(text, MAX_PATH);
#else
    PathRemoveFileSpecW(text);
#endif
    pathlen = wchartoutf8(text, 0, 0, 0);
    if (pathlen == 0) {
        return 0;
    }
    path = (char *)malloc(pathlen);
    if (path)
        pathlen = wchartoutf8(text, 0, path, pathlen);
    return path;
}

#elif defined(__APPLE__)

#include <mach-o/dyld.h>

char *execdir_thisexecdir()
{
    uint32_t size = 0;
    char *path;
    _NSGetExecutablePath(nullptr, &size);
    char *path = (char*)malloc(size+1);
    if (path) {
        char *slash;
        _NSGetExecutablePath(path, &size);
        getfather(path);
    }
    return path;
}

#else
/* Linux, Unix etc. */

#include <unistd.h>
#include <limits.h>
#include <string.h>

#ifdef DEBUG
#include <stdio.h>
#define DEBLOG(X) fprintf X
#else
#define DEBLOG(X)
#endif

char *argv0;

void execdir_setargv0(const char *av0)
{
    argv0 = strdup(av0);
}

char *execdir_thisexecdir()
{
    char pathbuf[PATH_MAX+2];
    char *pathenv;

    /* First try the Linux way. */
    ssize_t buff_len = readlink("/proc/self/exe", pathbuf, sizeof(pathbuf) - 1);
    if (buff_len != -1) {
        pathbuf[buff_len] = 0;
        getfather(pathbuf);
        return strdup(pathbuf);
    }

    // Other methods need argv0 to be set.
    if (!argv0 || argv0[0] == 0) {
        return NULL;
    }
    
    /* Check for an absolute path. We're done then */
    if (argv0[0] == '/') {
        return strdup(argv0);
    }
        
    /* If it's a relative path containing a slash (e.g., "./program"), resolve it using realpath.
     *
     * This will succeed even if it contains a relative path, as realpath() will call
     * getcwd().
     *
     * Only do it if argv0 contains a '/' as, otherwise, we need to use PATH ('.' may not be first
     * or in the PATH at all, and it would be wrong to return a result from the current
     * directory without checking PATH) */
    if (strchr(argv0, '/') != NULL) {
        if (realpath(argv0, pathbuf)) {
            getfather(pathbuf);
            return strdup(pathbuf);
        }
    }    

    /* Try the PATH. */
    if (NULL == (pathenv = getenv("PATH")) || NULL == (pathenv = strdup(pathenv))) {
        return NULL;
    }
    char *st = pathenv;
    char *nd = strchr(st, ':');
    char *trdir;
    for (;;) {
        if (NULL != nd) {
            *nd = '\0';
        }
        if (st[0] == 0) {
            trdir = ".";
        } else {
            trdir = st;
        }
        snprintf(pathbuf, PATH_MAX, "%s/%s", trdir, argv0);
        if (access(pathbuf, X_OK) == 0) {
            char abspath[PATH_MAX + 1];
            if (realpath(trdir, abspath)) {
                free (pathenv);
                return strdup(abspath);
            }
        }
        if (NULL == nd)
            break;
        st = nd+1;
        nd = strchr(st, ':');
    }

    free(pathenv);
    return NULL;
}

#ifdef TEST_MAIN
#include <stdio.h>
int main(int argc, char ** argv)
{
    char *thedir;
    execdir_setargv0(argv[0]);
    thedir = execdir_thisexecdir();
    if (thedir) {
        printf("directory: [%s]\n", thedir);
        free(thedir);
        exit(0);
    } else {
        fprintf(stderr, "execdir_thisexecdir failed\n");
        exit(1);
    }
}
#endif /* TEST_MAIN */
#endif /* !_WIN32 && !__APPLE__ */
