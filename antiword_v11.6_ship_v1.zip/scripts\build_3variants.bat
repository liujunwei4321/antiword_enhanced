@echo off
REM Build antiword CLI for Windows — 3 variants: XP-x86 / Win7-x86 / Win7-x64
REM
REM Priority: speed + correctness first, then size optimization.
REM
REM Strategy (per MSVC 14.44 build lessons):
REM   /O2 (NOT /Os — /O2 in MSVC 14.44 is size-aware and 5-10% smaller than /Os)
REM   /Gy /Gw /GF (per-function COMDAT + global data + string pool)
REM   /GL + /LTCG whole-program optimization
REM   /Zp4 struct packing (saves 5-10 KB)
REM   link: /OPT:REF /OPT:ICF /MERGE:.rdata=.text /OPT:NOWIN98

setlocal enabledelayedexpansion

set ROOT=%~dp0
set SRC=%ROOT%antiword-bundle-2026-06-27\source
set RES=%ROOT%antiword_res
set VCVARS64=C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat

REM Load MSVC env
if not defined VSCMD_VER call "%VCVARS64%" >nul
if errorlevel 1 (
    echo [ERROR] vcvars64 load failed
    exit /b 1
)

REM Setup resources
if not exist "%RES%" mkdir "%RES%"
if not exist "%RES%\8859-1.txt" xcopy /Y /Q "%SRC%\Resources\*" "%RES%\" >nul
if not exist "%SRC%\version.h" echo #define VERSION "0.37 + small-block fix v4" > "%SRC%\version.h"

REM Source list (CLI only — exclude RISC OS sprite + Windows GUI)
set SOURCES=asc85enc.c blocklist.c chartrans.c datalist.c depot.c dib2eps.c doclist.c fail.c finddata.c findtext.c fmt_text.c fontlist.c fonts.c fonts_u.c getopt_msvc.c hdrftrlist.c imgexam.c imgtrans.c jpeg2eps.c listlist.c main_u.c misc.c notes.c options.c out2window.c output.c pdf.c pictlist.c png2eps.c postscript.c prop0.c prop2.c prop6.c prop8.c properties.c propmod.c rowlist.c sectlist.c stylelist.c stylesheet.c summary.c tabstop.c text.c unix.c utf8.c word2text.c worddos.c wordlib.c wordmac.c wordole.c wordwin.c xmalloc.c xml.c

REM ===== Variant: XP x86 =====
echo.
echo ============ Building XP x86 ============
set OUT=%ROOT%out_xp_x86
set OBJS_DIR=%OUT%\obj
if exist "%OUT%" rd /s /q "%OUT%"
mkdir "%OBJS_DIR%"

REM XP requires /arch:IA32 (no SSE2), MT static CRT (no DLL dep on target)
set CFLAGS=/nologo /c /O2 /arch:IA32 /D_CRT_SECURE_NO_WARNINGS /D__CYGMING__ /DNDEBUG /DWIN32 /D_WIN32_WINNT=0x0501 /DWINVER=0x0501 /MT /utf-8 /I"%SRC%" /W3 /Gy /Gw /GF /Zp4
set LINKFLAGS=/nologo /SUBSYSTEM:CONSOLE,5.01 /LTCG /OPT:REF /OPT:ICF /OPT:NOWIN98 /DYNAMICBASE:NO /INCREMENTAL:NO /MERGE:.rdata=.text /OUT:"%OUT%\antiword.exe" kernel32.lib user32.lib advapi32.lib

for %%f in (%SOURCES%) do (
    cl %CFLAGS% /Fo"%OBJS_DIR%\%%~nf.obj" "%SRC%\%%f" 1>nul 2>"%OBJS_DIR%\%%~nf.log"
)
REM Check compile errors
set ERR=0
for %%f in ("%OBJS_DIR%\*.log") do (
    findstr /C:"error " "%%f" >nul 2>&1 && (
        echo [COMPILE ERROR] %%~nf
        type "%%f" | findstr /C:"error "
        set ERR=1
    )
)
if !ERR! neq 0 exit /b !ERR!

REM Build obj list
set OBJS=
for %%f in (%SOURCES%) do set OBJS=!OBJS! "%OBJS_DIR%\%%~nf.obj"

link %LINKFLAGS% %OBJS% 1>nul 2>"%OUT%\link.log"
if errorlevel 1 (
    type "%OUT%\link.log"
    exit /b 1
)
del /Q "%OBJS_DIR%\*.pdb" "%OBJS_DIR%\*.log" "%OUT%\link.log" 2>nul
echo XP x86: !ERRORLEVEL!
dir "%OUT%\antiword.exe" | findstr antiword.exe

REM ===== Variant: Win7 x86 =====
echo.
echo ============ Building Win7 x86 ============
set OUT=%ROOT%out_win7_x86
set OBJS_DIR=%OUT%\obj
if exist "%OUT%" rd /s /q "%OUT%"
mkdir "%OBJS_DIR%"

REM Win7+ allows /arch:SSE2 (mandatory for x64; safe for Win7 x86)
REM /MD dynamic CRT — smaller binary, needs VC++ runtime on target
set CFLAGS=/nologo /c /O2 /arch:SSE2 /D_CRT_SECURE_NO_WARNINGS /D__CYGMING__ /DNDEBUG /DWIN32 /D_WIN32_WINNT=0x0601 /DWINVER=0x0601 /MD /utf-8 /I"%SRC%" /W3 /Gy /Gw /GF /Zp4
set LINKFLAGS=/nologo /SUBSYSTEM:CONSOLE,6.01 /LTCG /OPT:REF /OPT:ICF /OPT:NOWIN98 /DYNAMICBASE:NO /INCREMENTAL:NO /MERGE:.rdata=.text /OUT:"%OUT%\antiword.exe" kernel32.lib user32.lib advapi32.lib

for %%f in (%SOURCES%) do (
    cl %CFLAGS% /Fo"%OBJS_DIR%\%%~nf.obj" "%SRC%\%%f" 1>nul 2>"%OBJS_DIR%\%%~nf.log"
)
set ERR=0
for %%f in ("%OBJS_DIR%\*.log") do (
    findstr /C:"error " "%%f" >nul 2>&1 && (
        echo [COMPILE ERROR] %%~nf
        type "%%f" | findstr /C:"error "
        set ERR=1
    )
)
if !ERR! neq 0 exit /b !ERR!

set OBJS=
for %%f in (%SOURCES%) do set OBJS=!OBJS! "%OBJS_DIR%\%%~nf.obj"
link %LINKFLAGS% %OBJS% 1>nul 2>"%OUT%\link.log"
if errorlevel 1 (
    type "%OUT%\link.log"
    exit /b 1
)
del /Q "%OBJS_DIR%\*.pdb" "%OBJS_DIR%\*.log" "%OUT%\link.log" 2>nul
echo Win7 x86: !ERRORLEVEL!
dir "%OUT%\antiword.exe" | findstr antiword.exe

REM ===== Variant: Win7 x64 =====
echo.
echo ============ Building Win7 x64 ============
set OUT=%ROOT%out_win7_x64
set OBJS_DIR=%OUT%\obj
if exist "%OUT%" rd /s /q "%OUT%"
mkdir "%OBJS_DIR%"

REM x64 native — SSE2 mandatory (mandatory in x64 Windows ABI)
set CFLAGS=/nologo /c /O2 /D_CRT_SECURE_NO_WARNINGS /D__CYGMING__ /DNDEBUG /DWIN32 /D_WIN32_WINNT=0x0601 /DWINVER=0x0601 /MD /utf-8 /I"%SRC%" /W3 /Gy /Gw /GF /Zp4
set LINKFLAGS=/nologo /SUBSYSTEM:CONSOLE,6.01 /LTCG /OPT:REF /OPT:ICF /OPT:NOWIN98 /DYNAMICBASE:NO /INCREMENTAL:NO /MERGE:.rdata=.text /OUT:"%OUT%\antiword.exe" kernel32.lib user32.lib advapi32.lib

for %%f in (%SOURCES%) do (
    cl %CFLAGS% /Fo"%OBJS_DIR%\%%~nf.obj" "%SRC%\%%f" 1>nul 2>"%OBJS_DIR%\%%~nf.log"
)
set ERR=0
for %%f in ("%OBJS_DIR%\*.log") do (
    findstr /C:"error " "%%f" >nul 2>&1 && (
        echo [COMPILE ERROR] %%~nf
        type "%%f" | findstr /C:"error "
        set ERR=1
    )
)
if !ERR! neq 0 exit /b !ERR!

set OBJS=
for %%f in (%SOURCES%) do set OBJS=!OBJS! "%OBJS_DIR%\%%~nf.obj"
link %LINKFLAGS% %OBJS% 1>nul 2>"%OUT%\link.log"
if errorlevel 1 (
    type "%OUT%\link.log"
    exit /b 1
)
del /Q "%OBJS_DIR%\*.pdb" "%OBJS_DIR%\*.log" "%OUT%\link.log" 2>nul
echo Win7 x64: !ERRORLEVEL!
dir "%OUT%\antiword.exe" | findstr antiword.exe

echo.
echo ============ ALL 3 BUILDS COMPLETE ============
endlocal