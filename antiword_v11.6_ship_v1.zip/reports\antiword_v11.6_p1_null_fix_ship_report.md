# antiword v11.6 (P1 NULL fix) ship report (2026-06-30)

## 起源

v11.5 ship (2026-06-29) 通过 deepseek 严格审计发现 **1 个 P1 high bug**：

- **wordlib.c** 的 `bIsZipFile` / `bIsXMLFile` / `bIsHTMLFile` (Recoll fork docx.patch) 入口没显式 NULL check
- 内部 `bCheckBytes` 走 `fail(pFile == NULL)`，但 **fail() 在 NDEBUG 是 noop**
- 后果：`bIsZipFile(NULL)` 走到 `rewind(NULL)` → NULL 解引用 crash
- 实际触发场景：上游 `main_u.c` 的 caller chain 不会出现 NULL pFile（fopen 失败早返），但是 **defense-in-depth** + Recoll 集成的整 9 个 patch 都缺这条防御

DeepSeek 同时标 1 个 P2（execdir_thisexecdir 死代码）+ 1 个 P3（execdir_setargv0 多次调泄漏）。user 拍板选 A：只修 P1。

## 改了什么

3 个函数 + 各自 5 行 NULL guard（3 行 if + 3 行注释）：

```c
BOOL bIsZipFile(FILE *pFile) {
    static const UCHAR aucBytes[] = { 'P', 'K', 0x03, 0x04 };
    DBG_MSG("bIsZipFile");
    /* P1 fix (DeepSeek v11.6 audit): bCheckBytes relies on fail() to
     * validate pFile, but fail() is a no-op under NDEBUG. Without this
     * explicit check, bIsZipFile(NULL) reaches rewind(NULL) and crashes. */
    if (pFile == NULL) {
        return FALSE;
    }
    return bCheckBytes(pFile, aucBytes, elementsof(aucBytes));
}
```

`bIsXMLFile` / `bIsHTMLFile` 各加相同 NULL guard。

## Build matrix

| Variant | Compiler | Target | Size (v11.6) | Size (v11.5) | Δ | SHA256 |
|---|---|---|---|---|---|---|
| **Linux x86_64** | gcc 9 (Kylin V10) | dynamic | 240440 B | 264704 B | -24 KB (-9%) | `80F83BE7FBA2CC33B744EF9F2E3938649BB03506093CB4BD1A1C00AF03F98E7E` |
| **Linux aarch64** | aarch64-linux-gnu-gcc 9 | dynamic | 227520 B | 265664 B | -38 KB (-14%) | `8EE338782682FDC1D53C87C73EC5B45A6641A72A9F9BEA252F9BCBB766B72A55` |
| **Linux loongarch64** | loongarch64-linux-gnu-gcc 8.3 | dynamic | 248456 B | 276552 B | -28 KB (-10%) | `C23F0885DDB52B22C37181E96BBD1EE8AA58B6E7C3416E9D30BCCC631BD7D0C9` |
| **Win XP x86** | MSVC 14.44.35207 | 32-bit, MT, IA32, subsys 5.01 | 375808 B | 388608 B | -12.8 KB (-3.3%) | `55797C24FE5E629043AD4B28D4DE4175D4152C2DAA13D0F4046273E9CB92B1B4` |
| **Win7 x86** | MSVC 14.44.35207 | 32-bit, MD, SSE2, subsys 6.01 | 185344 B | 193536 B | -8.2 KB (-4.2%) | `DC8C7C25CA687B8BDF5A4B70AD5BFF2556F5BB01201302F6EE539125867C87EB` |
| **Win7 x64** | MSVC 14.44.35207 | 64-bit, MD, subsys 6.01 | 224768 B | 225792 B | -1.0 KB (-0.4%) | `65EF3A9C5C85141F7F892E733EAFCDAA2E338B5EFEEDA97CE23DE4B0BDB00CE5` |

总 size: 1.4 MB → 1.25 MB (-150KB / -10.7%)。3 行 NULL guard 让 binary 略小 — LTCG/ICF 把冗余分支优化掉。

## 已知正确性 (基线 PASS, byte-exact 复述)

- **3.doc** (small-block WPS, 10240 B) → "Word文件，标记苹果" (md5 `62AB4BFAE12E3EB3D7D65C64D02DE669` 31B)
- **small_stream_plain.doc** (small-block WPS, 9728 B) → "这是doc文档，用wps建立和保存。" (md5 `3DCE2CAE5A231FB2CA06A99D5FC8A145` 46B)
- **CUPT介绍.doc** → 26073 B output (md5 `C6E9F1CDBBF58A7D058B7182DF3C3D6F`)
- **热敏电阻综合实验仪.doc** → 6716 B output (md5 `025B3F1F42D487611B8C46F01985EC81`)
- **plaindocx.docx** → "is not a Word Document. It seems to be a ZIP file, so is probably an OpenDocument file, or a 'docx' file from MS Word 2007 or newer" (Recoll fork docx.patch 正确触发)
- **3 个 MSVC 变体 byte-exact 互相对齐** (md5 hash 一致)
- **3 个 MSVC 变体 byte-exact 跟 v11.5 baseline 兼容** (md5 hash 一致)

## E2E 验证

| 测试 | v11.5 baseline | v11.6 v12 | Δ |
|---|---|---|---|
| out-of-place byte-exact 5 样本 × 3 MSVC 变体 | 20/20 PASS | 20/20 PASS | ✓ |
| in-place 4 样本 (3 变体) | 4/4 MATCH | 4/4 MATCH | ✓ |
| 7 特殊文件名 | 7/7 PASS | 7/7 PASS | ✓ |
| testdoc/ folder 4 .doc (3 PASS + 1 WPS not Word, 跟 baseline 一致) | baseline match | baseline match | ✓ |
| plaindocx.docx 错误信息 | "ZIP file..." | "ZIP file..." | ✓ |
| ssh1 x86_64 / aarch64 / loongarch64 跟 v11.5 baseline | baseline match | baseline match | ✓ |
| 0 crash / 0 regression | baseline | baseline | ✓ |

## 已知 ship 6 binaries

```
D:\sjz\release\antiword_x86_64_v11.6_smallblock_plus_recoll_NULLfix_v1.exe       240440 B
D:\sjz\release\antiword_aarch64_v11.6_smallblock_plus_recoll_NULLfix_v1          227520 B
D:\sjz\release\antiword_loongarch64_v11.6_smallblock_plus_recoll_NULLfix_v1     248456 B
D:\sjz\release\antiword_xp_x86_v11.6_smallblock_plus_recoll_NULLfix_v1.exe       375808 B
D:\sjz\release\antiword_win7_x86_v11.6_smallblock_plus_recoll_NULLfix_v1.exe     185344 B
D:\sjz\release\antiword_win7_x64_v11.6_smallblock_plus_recoll_NULLfix_v1.exe     224768 B
```

文件名后缀 `NULLfix_v1` 标识这次 ship 是 **P1 NULL check fix**，跟 v11.5 baseline 区分。

## 没改的已知项

- **P2 execdir_thisexecdir 死代码** (deepseek 标) — Recoll fork 集成的 `szGetGlobalAntiwordDir()` 没移植，execdir_thisexecdir() 没 caller。user 拍板先不修。
- **P3 execdir_setargv0 多次调泄漏** (deepseek 标) — 单次调用无影响。
- **22 bReadStream call sites** — Round 1 已 audit 通过，v11.6 没改。
- **bCheckBytes 本身** (deepseek 标 [VENDOR]) — 这是 antiword 上游 vendor 代码，不在 Recoll patch 范围，**vendor bug 不修**。
- **bIsWordForDosFile / bIsMacWord45File / bIsRtfFile / bIsWordPerfectFile** (deepseek 隐含 [VENDOR]) — 同样 vendor，**vendor bug 不修**。

## 工程流程教训 (这次 session)

1. **不要相信 "v11.5 verify PASS"** — v11.5 verify 全过（e2e byte-exact + 4 变体 + 7 special），但 deepseek 2 轮 review 抓出 1 真 P1 + 1 P2 + 1 P3。说明 byte-exact ≠ 全部 cover。
2. **P0 atomic 修法的 fail() noop 是真 bug class** — fail() 在 NDEBUG 是 noop，caller 必须 explicit if + return 防御。bCheckBytes 失败 path + bIs*File caller chain 暴露了这个 case。
3. **deepseek 报告"被审核的 P3"列 False Positive** — execdir 多次调泄漏 P3 严格说不是 bug，单次调用无影响。
4. **双 review 印证** — 我自己独立 round 2 审计 + deepseek 2 轮 audit 高度一致，**bCheckBytes NULL 风险**被双确认是真问题。

## 关键工程规范 (跨 session 复用)

- **P0 atomic 修法的 fail() noop** → 任何用 `fail(e)` 防御的代码必须 explicit if + return
- **C99 inline 严格 forward decl** (MSVC C4090) — round 13 教训
- **POSIX shim 头文件** (`_POSIX_C_SOURCE 200809L`) 必须 #define 在所有 system header 之前
- **C shim + Windows MSVC shim 两侧对齐** — short-circuit POSIX-only signal
- **cross dlopen free 安全性** — 必须 trace 到 caller 跟 callee 同 libc namespace
- **size_t 跨平台** (LP64 Linux vs LLP64 Windows 64-bit) — round 13 size_t overflow 教训
- **3 行 NULL guard + 2 行注释** — 闭环真实 crash 风险, 3 行 patch
- **byte-exact 比对** — `cmd /c "chcp 65001 >nul & exe > file"` 拿 raw binary, 用 `Get-FileHash -Algorithm MD5` 比 md5（避开 PowerShell Out-File 重新编码加 UTF-8 BOM 干扰）
