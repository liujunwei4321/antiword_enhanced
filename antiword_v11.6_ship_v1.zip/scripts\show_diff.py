#!/usr/bin/env python3
"""Show byte-level diff between v11.5 baseline and v11.6 new build"""
import os
import sys
from pathlib import Path

results_dir = Path(r"D:\sjz\antiword_msvc\test_docs\results")
new_dir = Path(r"D:\tmp\test_xp_x86")

# Pair by size
pairs = [
    ("3.doc.txt",                              "xp_x86_3.doc.txt"),
    ("CUPT_lf.txt",                            "xp_x86_CUPT__.doc.txt"),
    ("这是doc文档 - plain.doc.txt",                "xp_x86_small_stream_plain.doc.txt"),
    ("热敏电阻综合实验�?doc.txt",                 "xp_x86__________.doc.txt"),
]

for baseline_name, new_name in pairs:
    # find baseline file
    baseline_file = None
    for f in results_dir.glob("*.txt"):
        if f.name == baseline_name:
            baseline_file = f
            break
    new_file = new_dir / new_name
    if not baseline_file or not new_file.exists():
        print(f"SKIP: {baseline_name} or {new_name} not found")
        continue

    b = baseline_file.read_bytes()
    n = new_file.read_bytes()
    print(f"\n=== {baseline_name} ({len(b)}B) vs {new_name} ({len(n)}B) ===")
    # Show first 200 bytes hex
    print(f"  baseline first 100B hex: {b[:100].hex()}")
    print(f"  new      first 100B hex: {n[:100].hex()}")
    # Show printable chars
    def show(c):
        return ''.join(chr(x) if 32 <= x < 127 else '.' for x in c[:80])
    print(f"  baseline ASCII: {show(b)}")
    print(f"  new      ASCII: {show(n)}")
