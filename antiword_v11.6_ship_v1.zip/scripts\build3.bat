@echo off
setlocal enabledelayedexpansion

set ROOT=D:\sjz\antiword_msvc
set SRC=%ROOT%\antiword-bundle-2026-06-27\source
set RES=%ROOT%\antiword_res
set VCVARS_BASE=C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build
set COMMON_LINK=/nologo /OPT:REF /OPT:ICF /INCREMENTAL:NO /MERGE:.rdata=.text

set SOURCES=asc85enc.c blocklist.c chartrans.c datalist.c depot.c dib2eps.c doclist.c fail.c finddata.c findtext.c fmt_text.c fontlist.c fonts.c fonts_u.c getopt_msvc.c hdrftrlist.c imgexam.c imgtrans.c jpeg2eps.c listlist.c main_u.c misc.c notes.c options.c out2window.c output.c pdf.c pictlist.c png2eps.c postscript.c prop0.c prop2.c prop6.c prop8.c properties.c propmod.c rowlist.c sectlist.c stylelist.c stylesheet.c summary.c tabstop.c text.c unix.c utf8.c word2text.c worddos.c wordlib.c wordmac.c wordole.c wordwin.c xmalloc.c xml.c

if not exist "%RES%\8859-1.txt" (
    mkdir "%RES%"
    xcopy /Y /Q "%SRC%\Resources\*" "%RES%\" >nul
)
if not exist "%SRC%\version.h" echo #define VERSION "0.37" > "%SRC%\version.h"

REM ============================================================
REM Variant 1: XP x86 (subsys 5.02, MT static, /arch:IA32)
REM ============================================================
echo === XP x86 ===
set OUT=%ROOT%\out_xp_x86
if exist "%OUT%" rd /s /q "%OUT%"
mkdir "%OUT%\obj"

call "%VCVARS_BASE%\vcvars32.bat" >nul
if errorlevel 1 (
    echo VCVARS32_FAIL
    exit /b 1
)

set CFLAGS=/nologo /c /O2 /arch:IA32 /D_CRT_SECURE_NO_WARNINGS /D__CYGMING__ /DNDEBUG /DWIN32 /D_WIN32_WINNT=0x0501 /DWINVER=0x0501 /MT /utf-8 /I"%SRC%" /W3 /Gy /Gw /GF /Zp4

for %%f in (%SOURCES%) do (
    cl %CFLAGS% /Fo"%OUT%\obj\%%~nf.obj" "%SRC%\%%f" 1>nul 2>"%OUT%\obj\%%~nf.log"
)

set OBJS=
for %%f in (%SOURCES%) do set OBJS=!OBJS! "%OUT%\obj\%%~nf.obj"
link %COMMON_LINK% /SUBSYSTEM:CONSOLE,5.02 /OUT:"%OUT%\antiword.exe" %OBJS% kernel32.lib user32.lib advapi32.lib 1>"%OUT%\link.log" 2>&1
echo XP-x86 link RC: !errorlevel!

REM ============================================================
REM Variant 2: Win7 x86 (subsys 6.01, MD dynamic, /arch:SSE2)
REM ============================================================
echo.
echo === Win7 x86 ===
set OUT=%ROOT%\out_win7_x86
if exist "%OUT%" rd /s /q "%OUT%"
mkdir "%OUT%\obj"

call "%VCVARS_BASE%\vcvars32.bat" >nul

set CFLAGS=/nologo /c /O2 /arch:SSE2 /D_CRT_SECURE_NO_WARNINGS /D__CYGMING__ /DNDEBUG /DWIN32 /D_WIN32_WINNT=0x0601 /DWINVER=0x0601 /MD /utf-8 /I"%SRC%" /W3 /Gy /Gw /GF /Zp4

for %%f in (%SOURCES%) do (
    cl %CFLAGS% /Fo"%OUT%\obj\%%~nf.obj" "%SRC%\%%f" 1>nul 2>"%OUT%\obj\%%~nf.log"
)

set OBJS=
for %%f in (%SOURCES%) do set OBJS=!OBJS! "%OUT%\obj\%%~nf.obj"
link %COMMON_LINK% /SUBSYSTEM:CONSOLE,6.01 /OUT:"%OUT%\antiword.exe" %OBJS% kernel32.lib user32.lib advapi32.lib 1>"%OUT%\link.log" 2>&1
echo Win7-x86 link RC: !errorlevel!

REM ============================================================
REM Variant 3: Win7 x64 (subsys 6.01, MD dynamic, native x64)
REM ============================================================
echo.
echo === Win7 x64 ===
set OUT=%ROOT%\out_win7_x64
if exist "%OUT%" rd /s /q "%OUT%"
mkdir "%OUT%\obj"

call "%VCVARS_BASE%\vcvars64.bat" >nul

set CFLAGS=/nologo /c /O2 /D_CRT_SECURE_NO_WARNINGS /D__CYGMING__ /DNDEBUG /DWIN32 /D_WIN32_WINNT=0x0601 /DWINVER=0x0601 /MD /utf-8 /I"%SRC%" /W3 /Gy /Gw /GF /Zp4

for %%f in (%SOURCES%) do (
    cl %CFLAGS% /Fo"%OUT%\obj\%%~nf.obj" "%SRC%\%%f" 1>nul 2>"%OUT%\obj\%%~nf.log"
)

set OBJS=
for %%f in (%SOURCES%) do set OBJS=!OBJS! "%OUT%\obj\%%~nf.obj"
link %COMMON_LINK% /SUBSYSTEM:CONSOLE,6.01 /OUT:"%OUT%\antiword.exe" %OBJS% kernel32.lib user32.lib advapi32.lib 1>"%OUT%\link.log" 2>&1
echo Win7-x64 link RC: !errorlevel!

REM Clean PDBs + logs
del /Q "%ROOT%\out_xp_x86\obj\*.pdb" "%ROOT%\out_xp_x86\obj\*.log" "%ROOT%\out_xp_x86\link.log" 2>nul
del /Q "%ROOT%\out_win7_x86\obj\*.pdb" "%ROOT%\out_win7_x86\obj\*.log" "%ROOT%\out_win7_x86\link.log" 2>nul
del /Q "%ROOT%\out_win7_x64\obj\*.pdb" "%ROOT%\out_win7_x64\obj\*.log" "%ROOT%\out_win7_x64\link.log" 2>nul

echo.
echo === ALL DONE ===
endlocal